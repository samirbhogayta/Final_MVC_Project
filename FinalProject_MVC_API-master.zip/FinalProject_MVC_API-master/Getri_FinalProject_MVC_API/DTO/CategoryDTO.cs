﻿namespace Getri_FinalProject_MVC_API.DTO
{
    public class CategoryDTO
    {
        public string CategoryName { get; set; }
    }
}
