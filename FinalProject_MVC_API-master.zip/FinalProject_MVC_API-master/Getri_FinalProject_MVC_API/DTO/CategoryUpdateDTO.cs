﻿namespace Getri_FinalProject_MVC_API.DTO
{
    public class CategoryUpdateDTO
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
