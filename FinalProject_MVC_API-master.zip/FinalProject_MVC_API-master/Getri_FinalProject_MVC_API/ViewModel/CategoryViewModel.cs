﻿namespace Getri_FinalProject_MVC_API.ViewModel
{
    public class CategoryViewModel
    {
        public string CategoryName { get; set; }
    }
}
