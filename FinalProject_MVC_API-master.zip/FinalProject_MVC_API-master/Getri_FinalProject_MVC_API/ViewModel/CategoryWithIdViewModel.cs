﻿namespace Getri_FinalProject_MVC_API.ViewModel
{
    public class CategoryWithIdViewModel
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
