﻿namespace Getri_FinalProject_MVC_API.ViewModel
{
    public class ProductInsertViewModel
    {
        public string? ProductName { get; set; }

        public string? ProductDescription { get; set; }

        public int? ProductPrice { get; set; }

        public int? CategoryId { get; set; }
    }
}
