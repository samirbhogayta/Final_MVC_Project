﻿namespace Getri_FinalProject_MVC_API.ViewModel
{
	public class ProductsViewModel
	{
		public List<ProductCreateViewModel> LstProductCreateViewModel { get; set; }

		public ProductCreateViewModel ProductCreateViewModel { get; set; }
	}
}
