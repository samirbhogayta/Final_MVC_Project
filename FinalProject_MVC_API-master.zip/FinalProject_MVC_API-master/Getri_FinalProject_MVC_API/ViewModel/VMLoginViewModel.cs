﻿namespace Getri_FinalProject_MVC_API.ViewModel
{
    public class VMLoginViewModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public bool KeepLoggedIn { get; set; }
    }
}
